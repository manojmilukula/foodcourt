module.exports.about=function(req,res){
    res.render('Generic-text',{title:'About'});
};